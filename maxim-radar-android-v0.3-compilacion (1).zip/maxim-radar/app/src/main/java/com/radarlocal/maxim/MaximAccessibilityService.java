package com.radarlocal.maxim;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.radarlocal.maxim.core.LearningEngine;
import com.radarlocal.maxim.core.OfferParser;
import com.radarlocal.maxim.core.TripMath;

import java.util.List;
import java.util.Locale;

/** Read only Maxim Driver's visible foreground screen, no automatic acceptance. */
public final class MaximAccessibilityService extends AccessibilityService {
    private static final String TARGET="com.taxsee.driver";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private TextView bubble;
    private long lastEvent=0,lastScreenshot=0;
    private boolean ocrBusy=false;
    private String lastShown="";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager=(WindowManager)getSystemService(WINDOW_SERVICE);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(event==null) return;
        CharSequence app=event.getPackageName();
        // All other applications are ignored. Their text is never accessed or recorded.
        if(app==null || !TARGET.contentEquals(app)) {hideBubble(); return;}
        long now=android.os.SystemClock.elapsedRealtime();
        if(now-lastEvent<1400) return;
        lastEvent=now;
        StringBuilder sb=new StringBuilder();
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root!=null) {
            try {gather(root,sb,0,new int[]{0});} finally {root.recycle();}
        }
        OfferParser.Offer offer=OfferParser.parse(sb.toString());
        if(offer.complete()) {
            acceptOffer(offer,"texto");
        } else {
            // Android 11+: if Taxsee renders UI as image/canvas, read a LOCAL OCR screenshot.
            if(now-lastScreenshot>=3500 && !ocrBusy) {
                lastScreenshot=now;
                screenshotAndRead();
            }
        }
    }
    private void gather(AccessibilityNodeInfo node,StringBuilder sb,int depth,int[] counter) {
        if(depth>22 || counter[0]++>250 || sb.length()>15000) return;
        if(node.getText()!=null) sb.append(node.getText()).append('\n');
        if(node.getContentDescription()!=null) sb.append(node.getContentDescription()).append('\n');
        for(int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child=node.getChild(i);
            if(child!=null) {
                try {gather(child,sb,depth+1,counter);} finally {child.recycle();}
            }
        }
    }
    private void screenshotAndRead() {
        if(Build.VERSION.SDK_INT<30) return;
        ocrBusy=true;
        // Remove our own overlay so it cannot contaminate the OCR input.
        hideBubble();
        handler.postDelayed(() -> {
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult result) {
                        HardwareBuffer buffer=result.getHardwareBuffer();
                        Bitmap image=null;
                        try {
                            Bitmap hw=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
                            if(hw!=null) image=hw.copy(Bitmap.Config.ARGB_8888,false);
                        } catch(Exception e) { /* inaccessible or secure frame */ }
                        finally {buffer.close();}
                        if(image==null) {ocrBusy=false; return;}
                        final Bitmap captured=image;
                        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                                .process(InputImage.fromBitmap(captured,0))
                                .addOnSuccessListener(resultText -> {
                                    OfferParser.Offer offer=OfferParser.parse(resultText.getText());
                                    if(offer.complete()) acceptOffer(offer,"OCR");
                                    else showBubble("MAXIM RADAR · Revisar datos\nFalta: "+offer.describeMissing(),1);
                                })
                                .addOnFailureListener(e -> showBubble("MAXIM RADAR · OCR no disponible",1))
                                .addOnCompleteListener(task -> {
                                    captured.recycle(); ocrBusy=false;
                                });
                    }
                    @Override public void onFailure(int errorCode) {
                        ocrBusy=false;
                        showBubble("MAXIM RADAR · Captura bloqueada",1);
                    }
                });
            } catch(Exception ex) {ocrBusy=false;}
        },150);
    }
    private void acceptOffer(OfferParser.Offer offer,String source) {
        try {
            TripMath.Input in=Prefs.inputForOffer(this,offer.fare,offer.pickupKm,offer.rideKm,
                    offer.pickupMin,offer.rideMin);
            TripMath.Result result=TripMath.calculate(in);
            LocalStore store=new LocalStore(this);
            store.saveOffer(in);
            List<LearningEngine.Sample> history=store.completedSamples();
            LearningEngine.Advice advice=LearningEngine.evaluate(result,history,
                    Prefs.minHour(this),Prefs.minKm(this),Prefs.configured(this));
            store.close();
            String estimate=(offer.pickupMin==null||offer.rideMin==null)?" · tiempo aprox.":"";
            showBubble(advice.title+"\n"+money(result.netPerHour)+"/h · " +money(result.netPerKm)+"/km"+
                    "\nMetas " + money(Prefs.minHour(this))+"/h · "+money(Prefs.minKm(this))+"/km"+estimate,
                    advice.tier);
        } catch(Exception e) { showBubble("MAXIM RADAR · Datos incompletos",1); }
    }
    private static String money(double v) {return "$"+String.format(Locale.forLanguageTag("es-AR"),"%,.0f",v);}
    private void showBubble(String value,int tier) {
        handler.post(() -> {
            if(value.equals(lastShown) && bubble!=null) return;
            hideBubble(); lastShown=value;
            if(windowManager==null) return;
            bubble=new TextView(this);
            bubble.setText(value); bubble.setTextColor(Color.WHITE);
            bubble.setTextSize(13);bubble.setPadding(22,14,22,14);
            bubble.setGravity(Gravity.CENTER);
            GradientDrawable shape=new GradientDrawable();
            shape.setCornerRadius(18);
            shape.setColor(tier==3 || tier==2?Color.rgb(16,111,65):
                    tier==1?Color.rgb(148,103,14):tier==0?Color.rgb(146,42,42):Color.rgb(38,51,69));
            bubble.setBackground(shape);
            WindowManager.LayoutParams params=new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.TRANSLUCENT);
            params.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;
            params.y=92;
            try {windowManager.addView(bubble,params);} catch(Exception e) {bubble=null;}
        });
    }
    private void hideBubble() {
        handler.post(() -> {
            if(bubble!=null && windowManager!=null) {
                try {windowManager.removeView(bubble);} catch(Exception ignored) {}
                bubble=null;lastShown="";
            }
        });
    }
    @Override public void onInterrupt() {hideBubble();}
    @Override public void onDestroy() {hideBubble();super.onDestroy();}
}
