package com.radarlocal.maxim;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.radarlocal.maxim.core.LearningEngine;
import com.radarlocal.maxim.core.TripMath;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Simple interface for Galaxy A20. Offers are detected automatically; completed rides require confirmation. */
public final class MainActivity extends Activity {
    private final Map<String,EditText> fields=new LinkedHashMap<>();
    private TextView feedback,history;
    private LocalStore store;
    private LinearLayout root;
    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        store=new LocalStore(this);
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,28,24,42);root.setBackgroundColor(Color.rgb(246,248,250));
        scroll.addView(root);
        setContentView(scroll);

        TextView title=label("MAXIM RADAR",26,Color.rgb(12,37,62),true);root.addView(title);
        root.addView(label("Mide rentabilidad real y aprende de viajes completados. Funciona localmente.",13,
                Color.DKGRAY,false));
        root.addView(label("",8,Color.GRAY,false));
        addButton("1 · Activar lectura de pantalla",()-> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(label("Buscá «Maxim Radar» en Accesibilidad y activalo. Solo lee Maxim Driver en primer plano.",12,
                Color.rgb(83,89,100),false));
        history=label("",14,Color.rgb(28,48,70),true);root.addView(history);
        addButton("2 · Cargar última oferta detectada",this::loadLatest);
        root.addView(label("Datos del viaje (podés corregirlos después)",17,Color.rgb(12,37,62),true));
        addField("fare","Tarifa ofrecida ($)","",false);
        addField("pickupKm","Kilómetros hasta el pasajero","",false);
        addField("rideKm","Kilómetros con pasajero","",false);
        addField("pickupMin","Minutos hasta el pasajero","",false);
        addField("rideMin","Minutos con pasajero","",false);
        root.addView(label("Objetivos: GANANCIA NETA POR HORA y POR KM",17,Color.rgb(12,37,62),true));
        addField("minHour","OBJETIVO · Ganancia neta por HORA ($/h)",String.valueOf(Prefs.minHour(this)),true);
        addField("minKm","OBJETIVO · Ganancia neta por KILÓMETRO ($/km)",String.valueOf(Prefs.minKm(this)),true);
        root.addView(label("Costos del vehículo (para calcular GANANCIA real)",15,Color.rgb(12,37,62),true));
        addField("commission","Comisión de Maxim (%)",String.valueOf(Prefs.commission(this)),true);
        addField("costKm","Costo real por km: combustible + mantenimiento + desgaste ($)",String.valueOf(Prefs.costKm(this)),true);
        addField("idle","Minutos promedio de espera entre viajes",String.valueOf(Prefs.idle(this)),true);
        addField("speed","Velocidad promedio para estimar minutos (km/h)",String.valueOf(Prefs.speed(this)),true);
        addButton("3 · Evaluar rentabilidad",this::evaluate);
        addButton("4 · Confirmar viaje COMPLETADO",this::saveCompleted);
        root.addView(label("Confirmá solo viajes realmente terminados. Podés ajustar importe, kilómetros y minutos reales antes de guardar.",12,
                Color.rgb(95,94,94),false));
        feedback=label("Ingresá un viaje para obtener su análisis.",16,Color.rgb(30,54,70),true);
        feedback.setPadding(15,20,15,20);root.addView(feedback);
        root.addView(label("Interpretación: ⭐ = entre las mejores oportunidades históricas, no un máximo garantizado de Maxim. " +
                "Se habilita con al menos 20 viajes confirmados y metas/costos definidos.",12,Color.DKGRAY,false));
        renderHistory();
    }
    @Override protected void onResume() {super.onResume();if(history!=null)renderHistory();}
    @Override protected void onDestroy() {if(store!=null)store.close();super.onDestroy();}
    private TextView label(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);
        v.setPadding(0,8,0,8);
        if(bold)v.setTypeface(null,1);
        return v;
    }
    private void addField(String key,String label,String value,boolean optional) {
        root.addView(label(label,13,Color.rgb(46,62,72),true));
        EditText e=new EditText(this);
        e.setSingleLine(true);e.setText(value);
        e.setTextSize(17);
        e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setHint(optional?"Configurar":"Obligatorio");
        e.setPadding(18,10,18,10);root.addView(e);
        fields.put(key,e);
    }
    private void addButton(String text,Runnable action) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextSize(14);
        b.setOnClickListener(v->action.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=10;
        root.addView(b,lp);
    }
    private double read(String key) {
        String value=fields.get(key).getText().toString().trim().replace(',','.');
        if(value.isEmpty()) throw new IllegalArgumentException("Falta: "+key);
        return Double.parseDouble(value);
    }
    private void savePrefs() {
        Prefs.setNumber(this,"commission",read("commission"));
        Prefs.setNumber(this,"costKm",read("costKm"));
        Prefs.setNumber(this,"idle",read("idle"));
        Prefs.setNumber(this,"minHour",read("minHour"));
        Prefs.setNumber(this,"minKm",read("minKm"));
        Prefs.setNumber(this,"speed",read("speed"));
    }
    private TripMath.Input getInput() {
        savePrefs();
        return new TripMath.Input(read("fare"),read("pickupKm"),read("rideKm"),read("pickupMin"),
                read("rideMin"),read("commission"),read("costKm"),read("idle"));
    }
    private void evaluate() {
        try {
            TripMath.Input in=getInput();TripMath.Result r=TripMath.calculate(in);
            LearningEngine.Advice advice=LearningEngine.evaluate(r,store.completedSamples(),
                    Prefs.minHour(this),Prefs.minKm(this),Prefs.configured(this));
            int color=advice.tier==3?Color.rgb(13,124,74):advice.tier==2?Color.rgb(13,124,74):
                    advice.tier==0?Color.rgb(172,36,48):advice.tier==1?Color.rgb(160,108,5):Color.rgb(29,62,110);
            feedback.setTextColor(color);
            feedback.setText(advice.title+
                    "\nPOR HORA: "+money(r.netPerHour)+" / meta "+money(Prefs.minHour(this))+
                    "\nPOR KILÓMETRO: "+money(r.netPerKm)+" / meta "+money(Prefs.minKm(this))+
                    "\nGanancia total estimada neta: "+money(r.net)+
                    "\nCosto total variable: "+money(r.variableCosts)+
                    "\nComisión: "+money(r.commission)+
                    "\n"+advice.detail);
        } catch(Exception e) {showError("Revisá todos los campos numéricos. "+e.getMessage());}
    }
    private void saveCompleted() {
        try {
            TripMath.Input in=getInput();TripMath.calculate(in);
            boolean saved=store.confirmCompleted(in);
            evaluate();renderHistory();
            Toast.makeText(this,saved?"Viaje confirmado y aprendido (base local)":"Este viaje ya se confirmó hace unos segundos",Toast.LENGTH_LONG).show();
        } catch(Exception e) {showError("No se guardó. "+e.getMessage());}
    }
    private void loadLatest() {
        TripMath.Input in=store.latestOffer();
        if(in==null) {showError("Todavía no se capturó ninguna oferta completa. Entrá en Maxim con la lectura activada.");return;}
        set("fare",in.fare);set("pickupKm",in.pickupKm);set("rideKm",in.rideKm);
        set("pickupMin",in.pickupMin);set("rideMin",in.rideMin);
        feedback.setText("Oferta detectada cargada. Los minutos podrían ser aproximados; corregilos con datos reales antes de confirmar.");
        evaluate();
    }
    private void set(String key,double value) {fields.get(key).setText(String.format(Locale.US,"%.2f",value));}
    private void showError(String text) {feedback.setTextColor(Color.rgb(162,45,38));feedback.setText(text);}
    private void renderHistory() {
        if(history!=null)history.setText("Ofertas por revisar: "+store.countOffers()+
                " · Viajes confirmados: "+store.countCompleted()+" · Entrenamiento: "+
                Math.min(100,store.countCompleted()*100/LearningEngine.REQUIRED_TRIPS)+" %");
    }
    private static String money(double value) {
        return "$"+String.format(Locale.forLanguageTag("es-AR"),"%,.0f",value);
    }
}
