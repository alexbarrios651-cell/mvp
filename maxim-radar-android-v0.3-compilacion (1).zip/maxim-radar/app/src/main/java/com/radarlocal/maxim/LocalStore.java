package com.radarlocal.maxim;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.radarlocal.maxim.core.LearningEngine;
import com.radarlocal.maxim.core.TripMath;
import java.util.ArrayList;
import java.util.List;

/** Strictly local storage: financial numbers only, no addresses or screenshots. */
public final class LocalStore extends SQLiteOpenHelper {
    public LocalStore(Context context) { super(context,"maxim_radar.db",null,1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE rides (id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "ts INTEGER NOT NULL, source TEXT NOT NULL, signature TEXT NOT NULL, " +
                "fare REAL NOT NULL, pickup_km REAL NOT NULL, ride_km REAL NOT NULL,"+
                "pickup_min REAL NOT NULL, ride_min REAL NOT NULL, commission_pct REAL NOT NULL,"+
                "cost_km REAL NOT NULL, idle_min REAL NOT NULL, net REAL NOT NULL, " +
                "net_h REAL NOT NULL, net_km REAL NOT NULL, completed INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX idx_rides_complete ON rides(completed,ts)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV,int newV) { /* v1 */ }
    private static String signature(TripMath.Input in) {
        return Math.round(in.fare)+"|"+Math.round(in.pickupKm*10)+"|"+Math.round(in.rideKm*10);
    }
    private static ContentValues values(TripMath.Input in,TripMath.Result r,String src,boolean done) {
        ContentValues cv=new ContentValues();
        cv.put("ts",System.currentTimeMillis()); cv.put("source",src);
        cv.put("signature",signature(in)); cv.put("fare",in.fare);
        cv.put("pickup_km",in.pickupKm); cv.put("ride_km",in.rideKm);
        cv.put("pickup_min",in.pickupMin); cv.put("ride_min",in.rideMin);
        cv.put("commission_pct",in.commissionPct); cv.put("cost_km",in.costPerKm);
        cv.put("idle_min",in.idleMin); cv.put("net",r.net);
        cv.put("net_h",r.netPerHour); cv.put("net_km",r.netPerKm);
        cv.put("completed",done?1:0);
        return cv;
    }
    /** Raw offer is separate from confirmed completed rides. Avoid refresh duplicates. */
    public synchronized void saveOffer(TripMath.Input in) {
        TripMath.Result r=TripMath.calculate(in);
        SQLiteDatabase db=getWritableDatabase();
        String sig=signature(in);
        try(Cursor c=db.rawQuery("SELECT 1 FROM rides WHERE signature=? AND ts>? LIMIT 1",
                new String[]{sig,String.valueOf(System.currentTimeMillis()-120000L)})) {
            if(c.moveToFirst()) return;
        }
        db.insert("rides",null,values(in,r,"maxim",false));
    }
    /** User explicit confirmation; never use merely a screen event to call this. */
    public synchronized boolean confirmCompleted(TripMath.Input in) {
        TripMath.Result r=TripMath.calculate(in);
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=values(in,r,"confirmed",true);
        String sig=signature(in);
        // Guard against accidental double-taps duplicating historical profitability.
        try (Cursor existing=db.rawQuery("SELECT 1 FROM rides WHERE completed=1 AND signature=? AND ts>? LIMIT 1",
                new String[]{sig,String.valueOf(System.currentTimeMillis()-90000L)})) {
            if(existing.moveToFirst()) return false;
        }
        // Associate confirmation with the last matching offer if available.
        try (Cursor c=db.rawQuery("SELECT id FROM rides WHERE completed=0 AND signature=? AND ts>? ORDER BY ts DESC LIMIT 1",
                new String[]{sig,String.valueOf(System.currentTimeMillis()-86400000L)})) {
            if(c.moveToFirst()) {
                db.update("rides",cv,"id=?",new String[]{String.valueOf(c.getLong(0))});
                return true;
            }
        }
        db.insert("rides",null,cv);
        return true;
    }
    public TripMath.Input latestOffer() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT fare,pickup_km,ride_km,pickup_min,ride_min,"+
                "commission_pct,cost_km,idle_min FROM rides WHERE completed=0 ORDER BY ts DESC LIMIT 1",null)) {
            if(c.moveToFirst()) return new TripMath.Input(c.getDouble(0),c.getDouble(1),c.getDouble(2),
                    c.getDouble(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getDouble(7));
        }
        return null;
    }
    public List<LearningEngine.Sample> completedSamples() {
        List<LearningEngine.Sample> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT net_h,net_km FROM rides WHERE completed=1 ORDER BY ts DESC LIMIT 60",null)) {
            while(c.moveToNext()) out.add(new LearningEngine.Sample(c.getDouble(0),c.getDouble(1)));
        }
        return out;
    }
    public int countCompleted() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM rides WHERE completed=1",null)) {
            return c.moveToFirst()?c.getInt(0):0;
        }
    }
    public int countOffers() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM rides WHERE completed=0",null)) {
            return c.moveToFirst()?c.getInt(0):0;
        }
    }
}
