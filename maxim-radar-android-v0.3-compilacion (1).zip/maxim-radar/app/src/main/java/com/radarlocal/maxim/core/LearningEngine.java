package com.radarlocal.maxim.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Compares a new offer with completed (never just detected) trips. */
public final class LearningEngine {
    public static final int REQUIRED_TRIPS = 20;
    private LearningEngine() {}
    public static final class Sample {
        public final double hourly, perKm;
        public Sample(double hourly, double perKm) { this.hourly=hourly; this.perKm=perKm; }
    }
    public static final class Advice {
        public final String title, detail;
        public final int tier; // -1 insufficient inputs, 0 red, 1 yellow, 2 green, 3 star
        public final int trainedOn;
        public final double topHourlyTarget;
        public Advice(String title, String detail, int tier, int trainedOn, double topHourlyTarget) {
            this.title=title; this.detail=detail; this.tier=tier;
            this.trainedOn=trainedOn; this.topHourlyTarget=topHourlyTarget;
        }
    }
    public static Advice evaluate(TripMath.Result candidate, List<Sample> completed,
                                  double minHourly, double minPerKm, boolean costsConfigured) {
        int n=completed.size();
        if (!costsConfigured || minHourly<=0 || minPerKm<=0)
            return new Advice("CONFIGURAR COSTOS", "Definí costo/km y mínimos de rentabilidad antes de recomendar viajes.", -1, n, 0);
        // The two driver-defined goals are the ONLY traffic-light criteria.
        boolean hourlyReached = candidate.net>0 && candidate.netPerHour>=minHourly;
        boolean kmReached = candidate.net>0 && candidate.netPerKm>=minPerKm;
        double hRatio=candidate.netPerHour/minHourly, kmRatio=candidate.netPerKm/minPerKm;
        if (!hourlyReached || !kmReached) {
            boolean closeToBoth = candidate.net>0 && hRatio>=0.90 && kmRatio>=0.90;
            String gaps = "Hora: " + (hourlyReached?"cumple":"por debajo") +
                    "; kilómetro: " + (kmReached?"cumple":"por debajo") + ".";
            return new Advice(hourlyReached || kmReached || closeToBoth ? "🟡 AMARILLO · EVALUAR" : "🔴 ROJO · BAJO OBJETIVO",
                    gaps, hourlyReached || kmReached || closeToBoth ? 1 : 0, n, 0);
        }
        if (n<REQUIRED_TRIPS)
            return new Advice("🟢 VERDE · CUMPLE AMBAS METAS", "Aprendizaje de la estrella: "+n+"/"+REQUIRED_TRIPS+" viajes completados.", 2, n, 0);
        List<Double> rates = new ArrayList<>(), kms = new ArrayList<>();
        for (Sample s : completed) {
            if (Double.isFinite(s.hourly) && Double.isFinite(s.perKm)) {
                rates.add(s.hourly); kms.add(s.perKm);
            }
        }
        if (rates.size()<REQUIRED_TRIPS)
            return new Advice("🟢 VERDE · CUMPLE AMBAS METAS", "Faltan viajes históricos válidos para la estrella.", 2, rates.size(), 0);
        Collections.sort(rates); Collections.sort(kms);
        double p85=percentile(rates, .85), p65km=percentile(kms, .65);
        if (candidate.netPerHour>=Math.max(minHourly,p85) && candidate.netPerKm>=Math.max(minPerKm,p65km))
            return new Advice("⭐ VERDE · OPORTUNIDAD TOP", "Cumple ambas metas y destaca frente a los viajes completados (P85/h + P65/km).", 3, rates.size(), p85);
        return new Advice("🟢 VERDE · CUMPLE AMBAS METAS", "Alcanza tus dos metas; la estrella requiere destacar también en el historial.", 2, rates.size(), p85);
    }
    private static double percentile(List<Double> sorted, double p) {
        if (sorted.isEmpty()) return 0;
        double index=(sorted.size()-1)*p;
        int lo=(int)Math.floor(index), hi=(int)Math.ceil(index);
        return sorted.get(lo) + (sorted.get(hi)-sorted.get(lo))*(index-lo);
    }
}
