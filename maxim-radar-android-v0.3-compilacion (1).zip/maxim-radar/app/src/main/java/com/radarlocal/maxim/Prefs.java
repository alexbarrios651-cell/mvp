package com.radarlocal.maxim;

import android.content.Context;
import android.content.SharedPreferences;
import com.radarlocal.maxim.core.TripMath;

public final class Prefs {
    private Prefs() {}
    private static SharedPreferences get(Context c) {return c.getSharedPreferences("driver",Context.MODE_PRIVATE);}
    public static double getNumber(Context c,String key,double defaultValue) {
        try {return Double.parseDouble(get(c).getString(key,""+defaultValue));} catch(Exception e) {return defaultValue;}
    }
    public static void setNumber(Context c,String key,double v) {
        get(c).edit().putString(key,String.valueOf(v)).apply();
    }
    public static double commission(Context c) {return getNumber(c,"commission",0);}
    public static double costKm(Context c) {return getNumber(c,"costKm",0);}
    public static double idle(Context c) {return getNumber(c,"idle",5);}
    public static double minHour(Context c) {return getNumber(c,"minHour",0);}
    public static double minKm(Context c) {return getNumber(c,"minKm",0);}
    public static double speed(Context c) {return getNumber(c,"speed",25);}
    public static boolean configured(Context c) {
        return costKm(c)>0 && minHour(c)>0 && minKm(c)>0 && speed(c)>0;
    }
    /** Filling unknown times is an explicitly approximate fallback, not GPS tracking. */
    public static TripMath.Input inputForOffer(Context c,double fare,double pickupKm,double rideKm,
                                                Double pickupMin,Double rideMin) {
        double speed=Math.max(5,speed(c));
        return new TripMath.Input(fare,pickupKm,rideKm,
                pickupMin==null?Math.max(1,pickupKm*60/speed):pickupMin,
                rideMin==null?Math.max(1,rideKm*60/speed):rideMin,
                commission(c),costKm(c),idle(c));
    }
}
