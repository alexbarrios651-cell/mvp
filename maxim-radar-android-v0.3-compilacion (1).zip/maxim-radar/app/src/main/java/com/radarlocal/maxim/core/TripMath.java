package com.radarlocal.maxim.core;

/** All money amounts are in the user's currency. No location/network required. */
public final class TripMath {
    private TripMath() {}

    public static final class Input {
        public double fare, pickupKm, rideKm, pickupMin, rideMin, commissionPct, costPerKm, idleMin;
        public Input(double fare, double pickupKm, double rideKm, double pickupMin, double rideMin,
                     double commissionPct, double costPerKm, double idleMin) {
            this.fare=fare; this.pickupKm=pickupKm; this.rideKm=rideKm;
            this.pickupMin=pickupMin; this.rideMin=rideMin;
            this.commissionPct=commissionPct; this.costPerKm=costPerKm; this.idleMin=idleMin;
        }
    }
    public static final class Result {
        public final double net, netPerHour, netPerKm, totalKm, totalMin, commission, variableCosts;
        Result(double net, double netPerHour, double netPerKm, double totalKm, double totalMin,
               double commission, double variableCosts) {
            this.net=net; this.netPerHour=netPerHour; this.netPerKm=netPerKm;
            this.totalKm=totalKm; this.totalMin=totalMin;
            this.commission=commission; this.variableCosts=variableCosts;
        }
    }
    public static Result calculate(Input in) {
        if (!Double.isFinite(in.fare) || in.fare<=0 || !Double.isFinite(in.pickupKm)
                || !Double.isFinite(in.rideKm) || in.pickupKm<0 || in.rideKm<=0
                || !Double.isFinite(in.pickupMin) || !Double.isFinite(in.rideMin)
                || in.pickupMin<0 || in.rideMin<=0 || !Double.isFinite(in.idleMin)
                || in.idleMin<0 || !Double.isFinite(in.commissionPct)
                || in.commissionPct<0 || in.commissionPct>100 || !Double.isFinite(in.costPerKm)
                || in.costPerKm<0) throw new IllegalArgumentException("Datos inválidos del viaje");
        double km = in.pickupKm + in.rideKm;
        double minutes = in.pickupMin + in.rideMin + in.idleMin;
        double commission = in.fare * in.commissionPct / 100.0;
        double costs = km * in.costPerKm;
        double net = in.fare - commission - costs;
        return new Result(net, net*60.0/minutes, net/km, km, minutes, commission, costs);
    }
}
