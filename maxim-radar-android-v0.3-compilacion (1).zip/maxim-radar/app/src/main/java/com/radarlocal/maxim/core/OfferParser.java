package com.radarlocal.maxim.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative parser. No star is shown unless fare AND both distance fields are identified.
 * Text layouts differ by country; screenshots from the actual A20 are needed to calibrate.
 */
public final class OfferParser {
    private OfferParser() {}
    private static final Pattern NUMBER=Pattern.compile("\\d{1,3}(?:[., ]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d+)?");
    private static final Pattern DIST=Pattern.compile("(\\d+(?:[.,]\\d+)?)\\s*(?:km|kil[oó]metros?)\\b",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
    private static final Pattern MIN=Pattern.compile("(\\d+(?:[.,]\\d+)?)\\s*(?:min|mins|minutos?)\\b",Pattern.CASE_INSENSITIVE);
    public static final class Offer {
        public Double fare, pickupKm, rideKm, pickupMin, rideMin;
        public boolean complete() { return fare!=null && pickupKm!=null && rideKm!=null && fare>0 && rideKm>0; }
        public String describeMissing() {
            StringBuilder b = new StringBuilder();
            if(fare==null) b.append("importe ");
            if(pickupKm==null) b.append("km hasta pasajero ");
            if(rideKm==null) b.append("km del viaje");
            return b.toString().trim();
        }
    }
    public static Offer parse(String raw) {
        Offer out = new Offer();
        if(raw==null || raw.isEmpty()) return out;
        String[] lines = raw.replace('\r','\n').split("\\n");
        Double moneyWithSymbol=null, moneyWithLabel=null;
        for(int i=0;i<lines.length;i++) {
            String line=lines[i].trim(); if(line.isEmpty()) continue;
            String norm=normalize(line);
            String plus = line;
            // OCR frequently yields label and numeric value on adjacent lines.
            if(i+1<lines.length && !lines[i+1].trim().isEmpty()) plus += " " + lines[i+1].trim();
            Matcher d=DIST.matcher(line); Matcher m=MIN.matcher(line);
            Double dist=d.find() ? decimal(d.group(1)) : null;
            Double min=m.find() ? decimal(m.group(1)) : null;
            boolean pickup=contains(norm,"recoger","recogida","pasajero","hasta el cliente","hasta cliente",
                    "hacia origen","a origen","distancia de llegada","acercamiento","recojo","pick up","pickup");
            boolean ride=contains(norm,"viaje","recorrido","hasta destino","al destino","ruta del pedido",
                    "distancia del viaje","trayecto","con pasajero","distancia del pedido",
                    "long. de la ruta","long de la ruta","longitud de la ruta");
            if(pickup && dist!=null && out.pickupKm==null) out.pickupKm=dist;
            if(ride && dist!=null && out.rideKm==null) out.rideKm=dist;
            if(pickup && min!=null && out.pickupMin==null) out.pickupMin=min;
            if(ride && min!=null && out.rideMin==null) out.rideMin=min;
            if(pickup && dist==null && i+1<lines.length && out.pickupKm==null) out.pickupKm=findDistance(lines[i+1]);
            if(ride && dist==null && i+1<lines.length && out.rideKm==null) out.rideKm=findDistance(lines[i+1]);
            // The displayed ride amount has to be explicitly marked, not just any number on the screen.
            if(contains(norm,"tarifa","importe","costo del pedido","valor del pedido",
                    "precio del pedido","pago por viaje","total del pedido","pago del pedido")) {
                Double val=findMoney(plus);
                if(val!=null) moneyWithLabel=val;
            }
            // Headers like «Confirmación ($1433)» are NOT the quoted fare.
            // Likewise, avoid negotiated price buttons, wallet credits and platform charges.
            if((line.contains("$") || norm.contains("ars ")) && !contains(norm,
                    "comision","bono","saldo","deuda","confirmacion","proponer precio",
                    "solicitar","en el lugar","cargo")) {
                Double val=findMoney(line);
                if(val!=null) {
                    // The offer fare is the amount immediately followed by its payment mode.
                    // This outranks other monetary amounts (including a confirmation header).
                    boolean paymentNext = i+1<lines.length && contains(normalize(lines[i+1]),
                            "en efectivo","mercado pago","tarjeta","transferencia");
                    if(paymentNext) moneyWithLabel=val;
                    else if(moneyWithSymbol==null) moneyWithSymbol=val;
                }
            }
        }
        // Maxim Argentina shows three values across the details card, with the labels
        // below them: "Hasta la dirección", "Tiempo de entrega", "Long. de la ...".
        // Only apply this ordering when BOTH exact labels exist and precisely two
        // distance values are visible; never guess from the "Más cercanos" list.
        String all=normalize(raw);
        if(out.pickupKm==null && out.rideKm==null && all.contains("hasta la direccion")
                && all.contains("long. de la")) {
            Matcher distanceMatches=DIST.matcher(raw);
            List<Double> distanceNumbers=new ArrayList<>();
            while(distanceMatches.find()) distanceNumbers.add(decimal(distanceMatches.group(1)));
            if(distanceNumbers.size()==2) {
                out.pickupKm=distanceNumbers.get(0);
                out.rideKm=distanceNumbers.get(1);
            }
        }
        out.fare=moneyWithLabel!=null?moneyWithLabel:moneyWithSymbol;
        return out;
    }
    static String normalize(String s) {
        return java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}","");
    }
    private static boolean contains(String s,String... parts) { for(String x:parts) if(s.contains(x)) return true; return false; }
    private static Double findDistance(String s) {
        Matcher m=DIST.matcher(s); return m.find()?decimal(m.group(1)):null;
    }
    private static Double findMoney(String s) {
        String line=s.replaceAll("(?i)ars"," ").replace("$"," ");
        Matcher m=NUMBER.matcher(line); Double best=null;
        while(m.find()) {
            Double v=money(m.group());
            if(v!=null && v>=100 && v<=2000000 && (best==null||v>best)) best=v;
        }
        return best;
    }
    /** Locale-aware: 1.500,50 or 1,500.50 or 1500. */
    private static Double money(String v) {
        v=v.replace(" ","");
        int dot=v.lastIndexOf('.'), comma=v.lastIndexOf(',');
        if(dot>=0 && comma>=0) {
            if(dot>comma) v=v.replace(",","");
            else v=v.replace(".","").replace(',','.');
        } else if(comma>=0) {
            if(v.length()-comma-1==3) v=v.replace(",","");
            else v=v.replace(',','.');
        } else if(dot>=0 && v.length()-dot-1==3) v=v.replace(".","");
        try{return Double.parseDouble(v);}catch(Exception ex){return null;}
    }
    private static Double decimal(String s) {
        try { return Double.parseDouble(s.replace(',','.')); } catch(Exception ex) {return null;}
    }
}
