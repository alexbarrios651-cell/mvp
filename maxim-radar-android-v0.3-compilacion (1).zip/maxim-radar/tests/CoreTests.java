import com.radarlocal.maxim.core.TripMath;
import com.radarlocal.maxim.core.LearningEngine;
import com.radarlocal.maxim.core.OfferParser;
import java.util.*;

public class CoreTests {
    static void check(boolean x,String m){if(!x)throw new AssertionError(m);}
    static void near(double a,double b) {check(Math.abs(a-b)<.01,"Expected "+b+", got "+a);}
    public static void main(String[] a){
        TripMath.Input in=new TripMath.Input(8500,2,4,5,20,10,200,5);
        TripMath.Result r=TripMath.calculate(in);
        near(r.net,6450); near(r.totalKm,6);near(r.netPerHour,12900);near(r.netPerKm,1075);
        boolean rejected=false;
        try{TripMath.calculate(new TripMath.Input(5,0,0,0,0,0,0,0));}catch(IllegalArgumentException e){rejected=true;}
        check(rejected,"Invalid trip rejected");
        check(OfferParser.parse("Tarifa del pedido\n$ 8.500\nRecoger pasajero 2,4 km\nViaje 6,3 km\n").complete(),"Labelled offer detected");
        OfferParser.Offer offer=OfferParser.parse("Importe: $ 9.450,00\nHasta el cliente 1,2 km 5 min\nRecorrido 8,7 km 21 min");
        near(offer.fare,9450);near(offer.pickupKm,1.2);near(offer.rideKm,8.7);
        check(!OfferParser.parse("$ 8.000\n2,1 km\n5,3 km").complete(),"Unlabelled distances not guessed");
        OfferParser.Offer screenshot1=OfferParser.parse("Maxim Argentina Mendoza\nEstándar\n$3400\nen efectivo\nCalle Emilio Civit 928\nTerminal del Sol\n3.2 km.\n9 min.\n1.9 km.\nHasta la dirección\nTiempo de entrega\nLong. de la\n$420\nSolicitar");
        check(screenshot1.complete(),"Maxim capture with label row parsed");
        near(screenshot1.fare,3400); near(screenshot1.pickupKm,3.2); near(screenshot1.rideKm,1.9);
        OfferParser.Offer screenshot2=OfferParser.parse("Maxim Argentina Mendoza\nEstándar\n$6600\nen efectivo\nCalle María Auxiliadora, 201\nUnidad Penal II\nProponer precio:\n$7300\nSolicitar por $6600");
        near(screenshot2.fare,6600);check(!screenshot2.complete(),"No km = no rentabilidad, even with fare");
        OfferParser.Offer screenshot3=OfferParser.parse("Maxim Argentina Mendoza\nEstándar\n$10100\nen efectivo\nCalle Hijo Irigoyen, 3490\n5.8 km.\n14 min.\n16.7 km.\nHasta la dirección\nTiempo de entrega\nLong. de la\n$1294.3\nSolicitar");
        check(screenshot3.complete(),"Maxim multilocation trip parsed");near(screenshot3.fare,10100);near(screenshot3.pickupKm,5.8);near(screenshot3.rideKm,16.7);
        OfferParser.Offer autoAssigned=OfferParser.parse(
                "Confirmación ($1433)\nAR Maxim Mendoza, Estándar\n$3900\nen efectivo\n"+
                "Calle Eusebio Blanco, 629\nHospital Central\n"+
                "1.6 km.\n2.7 km.\nHasta la dirección\nLong. de la ruta\n"+
                "+ $495.2\nCliente Tamara\nEn el lugar dentro de 5 min.\nRechazar\nAceptar");
        check(autoAssigned.complete(), "Auto-assigned confirmation must be parsed");
        near(autoAssigned.fare,3900);near(autoAssigned.pickupKm,1.6);near(autoAssigned.rideKm,2.7);
        check(autoAssigned.pickupMin==null && autoAssigned.rideMin==null,
                "Arrival deadline must not be confused with travel time");
        TripMath.Result autoCalculated=TripMath.calculate(new TripMath.Input(
                3900,1.6,2.7,1.6*60/25.0,2.7*60/25.0,12.7,200,5));
        near(autoCalculated.totalKm,4.3);
        // $495.2 shown by Maxim is not a commission unless confirmed by the driver.
        near(autoCalculated.commission,495.3);
        List<LearningEngine.Sample> samples=new ArrayList<>();
        for(int i=0;i<25;i++) samples.add(new LearningEngine.Sample(6000+i*100,500+i*10));
        check(LearningEngine.evaluate(r,samples,3000,400,true).tier==3,"Top ride is starred");
        check(LearningEngine.evaluate(r,samples.subList(0,9),3000,400,true).tier!=3,"No stars without 20 samples");
        check(LearningEngine.evaluate(r,samples,3000,400,false).tier==-1,"No stars without cost configuration");
        check(LearningEngine.evaluate(r,samples,12000,1200,true).tier==1,"Yellow: hourly goal only");
        check(LearningEngine.evaluate(r,samples,14000,1200,true).tier==0,"Red: neither goal reached");
        check(LearningEngine.evaluate(r,samples,13000,1100,true).tier==1,"Yellow: near both goals");
        check(LearningEngine.evaluate(r,samples,12500,1000,true).tier==3,"Star can only appear above both goals");
        check(LearningEngine.evaluate(r,samples,3000,400,true).tier==3,"Both metrics star");
        System.out.println("CORE TESTS: OK (math, parser, hourly + per km goals, traffic lights, star gate)");
    }
}
