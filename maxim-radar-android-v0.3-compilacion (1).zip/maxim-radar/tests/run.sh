#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/maxim_radar_classes
javac -d /tmp/maxim_radar_classes app/src/main/java/com/radarlocal/maxim/core/*.java tests/CoreTests.java
java -cp /tmp/maxim_radar_classes CoreTests
