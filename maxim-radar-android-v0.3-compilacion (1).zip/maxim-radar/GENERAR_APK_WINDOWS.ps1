# Maxim Radar - genera un APK de depuracion instalable sin Android Studio.
# Requiere Windows 10/11, Internet, espacio libre y Java 17+ (tambien sirve el JBR de Android Studio).
# Ejecutar en PowerShell desde la carpeta del proyecto.
param()
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location $PSScriptRoot

function Descargar([string]$Url,[string]$Destino) {
    if (-not (Test-Path $Destino)) {
        Write-Host "Descargando $Url ..." -ForegroundColor Cyan
        Invoke-WebRequest -Uri $Url -OutFile $Destino -UseBasicParsing
    }
}
function Exigir([bool]$Condicion,[string]$Mensaje) {
    if (-not $Condicion) { throw $Mensaje }
}
try {
    $java = Get-Command java -ErrorAction SilentlyContinue
    if (-not $java) {
        $jbr = Join-Path ${env:ProgramFiles} 'Android\Android Studio\jbr'
        if (Test-Path (Join-Path $jbr 'bin\java.exe')) {
            $env:JAVA_HOME = $jbr
            $env:PATH = (Join-Path $jbr 'bin') + ';' + $env:PATH
        } else {
            throw 'No hay Java instalado. Instalá Android Studio o JDK 17 antes de ejecutar este script.'
        }
    }
    Write-Host 'Java encontrado. Se requiere JDK 17 o superior.'
    $sdk = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
    $env:ANDROID_HOME = $sdk
    $env:ANDROID_SDK_ROOT = $sdk
    $cache = Join-Path $PSScriptRoot '.build-cache'
    New-Item -Path $sdk,$cache -ItemType Directory -Force | Out-Null

    $sdkmanager = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
    if (-not (Test-Path $sdkmanager)) {
        $sdkzip = Join-Path $cache 'commandline-tools-windows.zip'
        Descargar 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' $sdkzip
        $actual = (Get-FileHash -Path $sdkzip -Algorithm SHA256).Hash.ToLowerInvariant()
        $expected = '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'
        Exigir ($actual -eq $expected) 'La descarga del Android SDK no coincide con el SHA-256 publicado por Google.'
        $temp = Join-Path $cache 'cmdline-unpacked'
        Expand-Archive -Path $sdkzip -DestinationPath $temp -Force
        $latest = Join-Path $sdk 'cmdline-tools\latest'
        New-Item -Path (Split-Path $latest -Parent) -ItemType Directory -Force | Out-Null
        if (Test-Path $latest) { Remove-Item $latest -Recurse -Force }
        Move-Item (Join-Path $temp 'cmdline-tools') $latest
        Remove-Item $temp -Recurse -Force
    }
    Exigir (Test-Path $sdkmanager) 'Fallo la instalacion de Android SDK Command Line Tools.'

    Write-Host 'Aceptando licencias oficiales del SDK e instalando paquetes necesarios...' -ForegroundColor Cyan
    1..100 | ForEach-Object { 'y' } | & $sdkmanager --sdk_root=$sdk --licenses | Out-Null
    & $sdkmanager --sdk_root=$sdk 'platforms;android-35' 'build-tools;35.0.0' 'platform-tools'
    Exigir ($LASTEXITCODE -eq 0) 'Android SDK no pudo instalar los paquetes requeridos.'

    $gradlezip = Join-Path $cache 'gradle-8.9-bin.zip'
    $gradleexe = Join-Path $cache 'gradle-8.9\bin\gradle.bat'
    if (-not (Test-Path $gradleexe)) {
        Descargar 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' $gradlezip
        Expand-Archive -Path $gradlezip -DestinationPath $cache -Force
    }
    Exigir (Test-Path $gradleexe) 'No se pudo descargar Gradle 8.9.'

    Write-Host 'Compilando Maxim Radar. La primera vez pueden descargarse dependencias grandes...' -ForegroundColor Cyan
    & $gradleexe --no-daemon --console=plain ':app:assembleDebug'
    Exigir ($LASTEXITCODE -eq 0) 'Falló la compilacion. Revisar el error de Gradle en la consola.'
    $inputApk = Join-Path $PSScriptRoot 'app\build\outputs\apk\debug\app-debug.apk'
    Exigir (Test-Path $inputApk) 'Gradle no produjo un APK.'
    $outputApk = Join-Path $PSScriptRoot 'Maxim-Radar-v0.3-instalar.apk'
    Copy-Item $inputApk $outputApk -Force
    Write-Host "`nAPK GENERADO: $outputApk" -ForegroundColor Green
    Write-Host 'Copialo al Samsung A20 e instalalo. Despues activa Accesibilidad > Maxim Radar.' -ForegroundColor Green
} catch {
    Write-Host ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
