# Maxim Radar — Android MVP 0.1 alpha

Aplicación experimental **independiente y no afiliada con Maxim / Taxsee** destinada a un Samsung A20 con Android 11 (API 30). No automatiza solicitudes de viajes. No requiere servidores, cuenta, Internet ni claves de Maxim.

## Estado de implementación

- **Implementado en el código fuente:** formulario, cálculo neto/hora y neto/km, parámetros de combustible/servicio/desgaste y comisión, SQLite local, registro de ofertas detectadas, confirmación manual de viajes, aprendizaje con los últimos 60 completados, estrella dorada al superar P85 por hora y P65 por km, mínimos personalizables, lectura de nodos de accesibilidad, captura + OCR local (ML Kit) si faltan datos en el árbol, superposición visual no interactiva.
- **Validado en este entorno:** pruebas independientes del núcleo de cálculos, parser y selección ⭐ (ver `tests/run.sh`).
- **Pendiente de validar en un dispositivo real:** compatibilidad con la pantalla real de los pedidos Maxim en Argentina, funcionamiento de OCR y superposición en el Samsung A20, rendimiento y eventuales capturas protegidas. No está disponible un APK precompilado porque este entorno no incluye Android SDK / Gradle descargados.

## Compilar APK con Android Studio

1. Instalar Android Studio y Android SDK 35 (si aún no está instalado).
2. Abrir la carpeta `maxim-radar` como proyecto Gradle; permitir sincronización con Google Maven. Android Studio puede solicitar instalar Android Gradle Plugin 8.7.3 y dependencias.
3. Menu **Build → Build APK(s)**.
4. APK de depuración en `app/build/outputs/apk/debug/app-debug.apk`.
5. Instalar en el A20 con Android 11, abrir Maxim Radar y activar su servicio en **Ajustes → Accesibilidad → Aplicaciones instaladas → Maxim Radar**. Los nombres exactos pueden cambiar con One UI.

Nota: al elegir un modelo ML Kit empaquetado en el APK, el tamaño crecerá. El reconocimiento OCR ocurre en el dispositivo.

## Configuración de la rentabilidad

Completar costo real por kilómetro, comisión (si la hay), tiempo de espera entre pedidos, objetivos mínimos por hora y por kilómetro, y velocidad media usada para estimar tiempos faltantes.

Fórmula por viaje:

```
km totales = km hasta recogida + km con pasajero
costo variable = km totales × costo por km
neto = tarifa - (tarifa × comisión %) - costo variable
minutos productivos = traslado a recogida + viaje + espera estimada entre pedidos
neto por hora = neto × 60 / minutos productivos
neto por km = neto / km totales
```

La espera promedio entre pedidos se incluye solo como aproximación configurable; no se mide automáticamente. El costo/km debe incorporar combustible, neumáticos, lubricantes, mantenimiento, depreciación y otros gastos proporcionales relevantes. Si hay peajes u otros cargos, deben contemplarse en la tarifa/costo efectivo antes de confirmar.

## Semáforo de objetivos: exactamente $/hora y $/kilómetro

La tarifa total del viaje **no es objetivo**; es una entrada para calcular dos indicadores:

- **VERDE**: el viaje alcanza tanto el objetivo de **ganancia neta por hora** como el objetivo de **ganancia neta por km**.
- **AMARILLO**: solo uno de los dos objetivos se alcanza, o ambos están al menos al 90 % del objetivo.
- **ROJO**: no se alcanza ninguno de los dos objetivos ni hay cercanía simultánea.
- **GRIS**: sin costos o metas configurados, no se clasifica como rentable.
- **⭐ sobre verde**: alcanza ambos objetivos y además destaca en el historial; nunca se usa la estrella para reemplazar el verde.

Los kilómetros suman recogida + trayecto con pasajero. Las horas suman recogida + trayecto + espera estimada. En capturas de Maxim, «Tiempo de entrega» podría referirse a la duración del trayecto; requiere confirmación contra una oferta real antes de asignarlo de forma automática.

## Estrella de oportunidades

- No se emiten estrellas con menos de **20 viajes completados confirmados**.
- Se toman los **últimos 60 viajes completados** registrados, nunca los ofrecidos no confirmados.
- Debe superar tanto el **percentil 85 de neto/hora** como el **percentil 65 de neto/km**, además de los mínimos establecidos por el conductor.
- No representa la tarifa máxima de Maxim ni una garantía; es la franja más conveniente de su propio historial.
- No se entrena un modelo pesado: estadística robusta incremental sobre SQLite local.

## Protección de datos

La app solo evalúa `com.taxsee.driver` cuando está en primer plano. No posee permiso de Internet, no guarda imágenes, textos de pantalla, direcciones, origen/destino, ubicación o nombres de pasajeros; solamente métricas económicas de ofertas y viajes. El servicio recibe eventos de cambio de ventana de otras apps para poder ocultar el indicador, pero no consulta su contenido. La base local se almacena en el área privada de Android y `allowBackup=false` impide copias de Android por defecto.

## Restricciones técnicas y próximos ajustes

La estructura visual de Maxim cambia entre regiones y versiones. Actualmente el parser exige importe y **dos distancias identificadas explícitamente**: hasta el pasajero y con pasajero; si no están rotuladas, falla en modo seguro y no inventa una recomendación. Se recibieron seis capturas de Maxim Argentina (detalle y lista, en Mendoza). Se añadieron reglas conservadoras de lectura para los rótulos «Hasta la dirección» y «Long. de la ...», y se corrigió la selección del importe principal para no confundirlo con «Proponer precio» ni con el valor pequeño del pie. Los tests cubren representaciones textuales de esas pantallas; aún hay que validar el orden REAL entregado por accesibilidad/OCR en un Samsung A20. Si no aparecen las dos distancias, no se calificará automáticamente el pedido. Algunos contenidos protegidos contra captura no podrán leerse por OCR. En ese caso queda disponible la carga manual.

**No usar como única fuente para decidir viajes durante la conducción.** La rentabilidad es una estimación basada en las entradas y costos definidos. La app no pulsa botones en Maxim.

## Pruebas

`bash tests/run.sh` (requiere JDK 17+; las pruebas del núcleo no requieren Android SDK).

## Actualización 0.3 — asignaciones automáticas de Maxim

Se añadió una prueba específica para la pantalla de «Confirmación ($1433)»: el **importe del viaje es $3900**, no el número del encabezado; se detectan 1,6 km de acercamiento y 2,7 km de recorrido (4,3 km total). «En el lugar dentro de 5 min.» es un plazo de llegada, no se reutiliza automáticamente como tiempo de viaje. El valor «+$495.2» **no se interpreta como comisión** hasta verificar su significado: se conserva la comisión porcentual configurable por el conductor.

Para compilar sin Android Studio en Windows, ejecutá `GENERAR_APK_WINDOWS.ps1` en PowerShell desde la carpeta del proyecto, con Java 17+ e Internet disponibles. El script descarga herramientas oficiales, instala los paquetes del SDK y Gradle, compila y guarda el APK final dentro de la carpeta del proyecto. No se ha podido probar el script completo en este entorno Linux sin conectividad; verificar el resultado antes de usar en una jornada real.

Para compilar en GitHub Actions, subí los archivos **interiores** de esta carpeta a la raíz de un repositorio GitHub. En la pestaña `Actions`, ejecutá `Compilar APK Maxim Radar` → `Run workflow`. El artefacto descargable incluirá `app-debug.apk`. No confundir APK de depuración con versión validada en un Samsung A20: es instalable pero experimental.
